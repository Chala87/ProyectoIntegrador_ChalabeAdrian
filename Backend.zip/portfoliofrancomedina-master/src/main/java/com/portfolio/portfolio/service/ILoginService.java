package com.portfolio.portfolio.service;

import com.portfolio.portfolio.model.Login;


public interface ILoginService {
    public boolean login(Login login);
}
