package com.portfolio.portfolio.service;

import com.portfolio.portfolio.model.Persona;



public interface iPersonaService {

    public void crearPersona(Persona persona);
    public Persona listarPersonas();

}
